"""Attachment routing rule engine."""
