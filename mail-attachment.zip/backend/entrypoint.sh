#!/usr/bin/env sh
set -eu

alembic upgrade head
exec uvicorn mailhub.main:app --host 0.0.0.0 --port 8080
